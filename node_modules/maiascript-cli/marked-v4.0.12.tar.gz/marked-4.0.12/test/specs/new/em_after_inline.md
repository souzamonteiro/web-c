a\
*@*

a*a*_a_*@*

a**a**_a_*@*

a~a~*@*

a`a`*@*

a<http://a.com>*@*

a[a](a)*@*

a<a>*@*
