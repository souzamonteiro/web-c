[reflink*top]: theaddress

*Hello [reflink*top] guys*!

*Hello [not*reflink] guys*!

*Hello [not*a*reflink] guys*!

*Hello [reflink*bottom] guys*!

*Hello [reflinknoem] guys*!

[reflink*bottom]: theaddress

[reflinknoem]: theaddress
