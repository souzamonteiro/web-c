---
pedantic: true
---
  * item1

    * item2

  text
