---
gfm: false
description: Task lists are ignored when not using GFM
---
- [ ] A
- [x] B
- [ ] C