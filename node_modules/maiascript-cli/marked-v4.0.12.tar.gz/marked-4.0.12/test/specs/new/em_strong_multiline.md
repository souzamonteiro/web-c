_italic **bold** italic_
_italic **bold** italic_
_italic **bold** italic_
