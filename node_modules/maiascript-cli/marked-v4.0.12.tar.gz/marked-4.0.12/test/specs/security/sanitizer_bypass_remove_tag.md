---
sanitize: true
sanitizer: () => ''
---
AAA<sometag> <img <sometag> src=x onerror=alert(1)BBB
